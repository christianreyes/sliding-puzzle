- - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Title:			Project 1: Sliding Puzzle!
Author : 		Christian Reyes 
Description:    	README for puzzle
Course:         	05-433D SSUI Web Lab
Created : 		08 Sep 2011
Modified : 		21 Sep 2011
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

Puzzle works in Google Chrome, IE, Firefox, IE, Android, and iPad.

Puzzle first shuffles the tiles then allows the user to click to move the tiles.

When 2x2 the puzzle can "solve" itself by shuffling. I left 2x2 in because it is
sometimes the only puzzle that a person can solve. It's nice to be able to solve
a puzzle...

I abstracted the tile from the div and put it in it's own js file.